drop index FLW_IDX_BATCH_PART;

drop table FLW_RU_BATCH_PART;
drop table FLW_RU_BATCH;