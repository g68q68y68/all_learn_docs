drop table ACT_GE_BYTEARRAY;
drop table ACT_GE_PROPERTY;