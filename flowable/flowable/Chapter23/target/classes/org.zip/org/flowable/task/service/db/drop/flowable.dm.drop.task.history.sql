drop index ACT_IDX_HI_TASK_SCOPE;
drop index ACT_IDX_HI_TASK_SUB_SCOPE;
drop index ACT_IDX_HI_TASK_SCOPE_DEF;

drop sequence act_hi_task_evt_log_seq;

drop table ACT_HI_TASKINST;
drop table ACT_HI_TSK_LOG;