package liquibase.datatype.core;

import liquibase.database.Database;
import liquibase.database.core.DmDatabase;
import liquibase.datatype.DataTypeInfo;
import liquibase.datatype.DatabaseDataType;

@DataTypeInfo(
        name = "boolean",
        aliases = {"java.sql.Types.BOOLEAN", "java.lang.Boolean", "bit", "bool"},
        minParameters = 0,
        maxParameters = 0,
        priority = 1
)
public class DmBooleanType extends BooleanType {

    @Override
    public DatabaseDataType toDatabaseDataType(Database database) {
        if (database instanceof DmDatabase) {
            return new DatabaseDataType("bit");
        }
        return super.toDatabaseDataType(database);
    }

    @Override
    protected boolean isNumericBoolean(Database database) {
        if (database instanceof DmDatabase) {
            return true;
        }
        return super.isNumericBoolean(database);
    }
}
